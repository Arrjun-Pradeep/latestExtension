import { Routes, Route } from 'react-router-dom';
import Landing from "./Components/Landing/Landing";
import ImportWallet from "./Components/ImportWallet/ImportWallet";
import CreateWallet from "./Components/CreateWallet/CreateWallet";
import Dashboard from "./Components/Dashboard/Dashboard";
import Transaction from './Components/Transaction/Transaction';
import Provider from './Components/Provider/Provider';
import Ethereum from './Components/Ethereum/Ethereum';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route exact path='/' element={<Landing />} />
        <Route exact path='/importWallet' element={<ImportWallet />} />
        <Route exact path='/createWallet' element={<CreateWallet />} />
        <Route exact path='/dashboard' element={<Dashboard />} />
        <Route exact path='/transactions' element={<Transaction />} />
        <Route exact path='/provider' element={<Provider />} />
        <Route exact path='/ethereum' element={<Ethereum />} />
      </Routes>
    </div>
  );
}

export default App;
