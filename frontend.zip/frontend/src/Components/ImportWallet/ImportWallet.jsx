import React, { useState, useEffect } from 'react';
import './ImportWallet.css';
import axios from '../../axios';
import { useNavigate } from 'react-router-dom';
/*global chrome*/

function ImportWallet() {

    let navigate = useNavigate();

    const [mnemonics, setMnemonics] = useState();
    const [password, setPassword] = useState();
    const [privateKey, setPrivateKey] = useState();
    const [address, setAddress] = useState();

    useEffect(() => {

    }, [])


    const importWalletFromSeed = async (e) => {

        e.preventDefault();

        try {

            let options = {
                mnemonics: mnemonics
            }



            await axios.post('/wallet/importWallet', options)
                .then(function (response) {
                    console.log(response.data.message);
                    setPrivateKey(response.data.message.privateKey);
                    setAddress(response.data.message.address);

                    let data =
                    {
                        "type": "Simple Key Pair",
                        "data": [String(response.data.message.privateKey)]
                    }

                    // let key = 'myKey';
                    // let value = { name: 'my value' };

                    // chrome.storage.local.set({ key: value }, () => {
                    //     console.log('Stored name: ', key, value.name);
                    // });

                    // key = 'myKey';
                    // chrome.storage.local.get([key], (result) => {
                    //     console.log('Retrieved name: ' + result.myKey);
                    // });



                })
                .catch(function (error) {
                    console.log(error);
                });

        } catch (error) {

            console.log(":: IMPORT_WALLET_FROM_SEED ::", error);
            return false;

        }

    }

    return (
        <div className="container">
            <form onSubmit={importWalletFromSeed}>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="mnemonics">Mnemonics</label>
                    </div>
                    <div className="col-75">
                        <input type="text" id="mnemonics" name="seed" placeholder="Mnemonics...." onChange={(e) => setMnemonics(e.target.value)} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="passwd">New Password</label>
                    </div>
                    <div className="col-75">
                        <input type="text" id="passwd" name="password" placeholder="Password...." onChange={(e) => setPassword(e.target.value)} />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="cpasswd">Confirm Password</label>
                    </div>
                    <div className="col-75">
                        <input type="text" id="cpasswd" name="cpassword" placeholder="Password...." />
                    </div>
                </div>
                <br />
                <div className="row">
                    <input type="submit" value="Submit" />
                </div>
            </form>

            <div className="row">
                <input type="submit" value="Next" onClick={() => navigate('/dashboard')} />
            </div>

            {privateKey && <div className="jumbotron">
                <p>PRIVATE KEY : {privateKey}</p>
                <p>ADDRESS : {address}</p>
            </div>}

        </div>
    )
}

export default ImportWallet