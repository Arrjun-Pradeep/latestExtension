import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function Transaction() {

  return (
    <div className="container">
      <form onSubmit>
        <div className="row">
          <div className="col-25">
            <label htmlFor="mnemonics">Mnemonics</label>
          </div>
          <div className="col-75">
            <input type="text" id="mnemonics" name="seed" placeholder="Mnemonics...." />
          </div>
        </div>
        <div className="row">
          <div className="col-25">
            <label htmlFor="passwd">New Password</label>
          </div>
          <div className="col-75">
            <input type="text" id="passwd" name="password" placeholder="Password...." />
          </div>
        </div>
        <div className="row">
          <div className="col-25">
            <label htmlFor="cpasswd">Confirm Password</label>
          </div>
          <div className="col-75">
            <input type="text" id="cpasswd" name="cpassword" placeholder="Password...." />
          </div>
        </div>
        <br />
        <div className="row">
          <input type="submit" value="Submit" />
        </div>
      </form>

      <div className="row">
        <input type="submit" value="Next" />
      </div>

      {/* {privateKey && <div className="jumbotron">
        <p>PRIVATE KEY : {privateKey}</p>
        <p>ADDRESS : {address}</p>
      </div>} */}

    </div>)
}

export default Transaction