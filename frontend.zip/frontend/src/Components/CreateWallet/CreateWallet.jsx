import React from 'react';
import { useState } from 'react';
import axios from '../../axios';
import './CreateWallet.css';
import { useNavigate } from 'react-router-dom';
/*global chrome*/

const CreateWallet = () => {

  let navigate = useNavigate();

  const [mnemonics, setMnemonics] = useState();
  const [password, setPassword] = useState();

  const password_store = (e) => {
    setPassword(e.target.value)
  }

  window.sessionStorage.setItem('Wallet_password',password);
  const generateMnemonics = async (e) => {

    e.preventDefault();

    try {

      let options = {
        entropyLength: '24',
        password: password
      }

      let Encrypted_data = {};
      Encrypted_data.data = {}
      Encrypted_data.password = password
      await axios.post('/wallet/login/seed', options)
        .then((response) => {
          console.log("Printing response data:", response);
          console.log("Printing response data:", response.data.data);
          Encrypted_data.data = response.data.data.message
          console.log("🚀 ~ file: CreateWallet.jsx:35 ~ generateMnemonics ~ Encrypted_data", Encrypted_data)
          chrome.storage.local.set({ 'wallet_data': Encrypted_data }, () => {
            console.log('INITIALIZE THE WALLET WITH ONE ADDRESS');
          });
        })
        .catch(function (error) {
          console.log(error);
        });

      //* to display mnemonics
      await axios.post('/wallet/login/fetch/seed', Encrypted_data)
        .then((result) => {
          console.log("ENCRYPTED FORMAT ---------->", result);
          console.log("ENCRYPTED FORMAT ---------->", result.data.data.return_data.data.mnemonic);
          if (result.data.data.return_data.data.mnemonic) {
            setMnemonics(result.data.data.return_data.data.mnemonic)
          }
        }).catch(function (error) {
          console.log(error);
        });

      //* reading from local
      await chrome.storage.local.get(['wallet_data'], (read_data) => {
        console.log('reading the stored data for verification', read_data);
      });
    } catch (error) {
      console.log(":: CREATE_NEW_WALLET ::", error);
      return false;
    }
  }

  return (
    <div className="container">
      <form onSubmit={generateMnemonics}>
        <div className="row">
          <div className="col-25">
            <label htmlFor="passwd">New Password</label>
          </div>
          <div className="col-75">
            <input type="text" id="passwd" name="password" placeholder="Password...." onChange={password_store} />
          </div>
        </div>
        <div className="row">
          <div className="col-25">
            <label htmlFor="cpasswd">Confirm Password</label>
          </div>
          <div className="col-75">
            <input type="text" id="cpasswd" name="cpassword" placeholder="Password...." />
          </div>
        </div>
        <br />
        <div className="row">
          <input type="submit" value="Submit" />
        </div>
      </form>

      <div className="row">
        <input type="submit" value="Next" onClick={() => navigate('/dashboard')} />
      </div>

      {mnemonics && <div className="jumbotron">
        <p>GENERATED MNEMONICS : <br /><br /> {mnemonics}</p>
      </div>}

    </div>)
}

export default CreateWallet