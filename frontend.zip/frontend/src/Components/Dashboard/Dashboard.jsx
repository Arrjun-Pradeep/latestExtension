import React from 'react';
import { useState } from 'react';
import './Dashboard.css';
import axios from '../../axios';
import { useNavigate } from 'react-router-dom';

// import $ from 'jquery';

/*global chrome*/

function Dashboard() {
let navigate = useNavigate();


  //* Created data  
  const [publicAddress, setPublicAddress] = useState([]);
  const [privateKey, setPrivateKey] = useState();
  const [importedAddress, setImportedAddress] = useState([]);

  //* imported private key

  const imp_private_key = (e) => {
    setPrivateKey(e.target.value)
  }

//* Create Account
  const createAccount = async (e) => {
    e.preventDefault();
    try {
      let options = {}
      let Encrypted_data = {};
      //* reading from local
      await chrome.storage.local.get(['wallet_data'], (read_data) => {
        console.log('reading the stored data for verification====>', read_data);
        options.data = read_data.wallet_data.data
        const mode = sessionStorage.getItem('Wallet_password');
        console.log("🚀 ~ file: Dashboard.jsx:44 ~ createAccount ~ mode", mode)
        options.password = mode
        console.log("🚀 ~ file: Dashboard.jsx:38 ~ createAccount ~ options", options)

        axios.post('/wallet/login/account', options)
          .then(function (response) {
            console.log('printing for Wallet generation response ', response);
            console.log('printing for Wallet generation response ', response.data.address);
            Encrypted_data.data = response.data.data.message
            console.log("🚀 ~ file: CreateWallet.jsx:35 ~ generateMnemonics ~ Encrypted_data", Encrypted_data)
            chrome.storage.local.set({ 'wallet_data': Encrypted_data }, () => {
              console.log('Response stored in chrome storage success');
            });
            setPublicAddress([...publicAddress, { id: Date.now(), address: response.data.address }]);
            chrome.storage.local.get(['wallet_data'], (read_data) => {
              console.log('Chrome storage data retrieved successfully==>', read_data);
            });
          })
          .catch(function (error) {
            console.log(error);
          });
      });
    } catch (error) {
      console.log(":: CREATE_ACCOUNT_ERROR ::", error);
    }
  }

  //* Import Account using PrivateKey
  const importAccountFromPrivateKey = async (e) => {
    e.preventDefault();
    try {
      let Encrypted_data = {};
      let options = {
        privateKey: privateKey
      }
      await chrome.storage.local.get(['wallet_data'], (read_data) => {
        console.log('reading the stored data for importAccount====>', read_data);
        options.data = read_data.wallet_data.data
        const mode = sessionStorage.getItem('Wallet_password');
        console.log("🚀 ~ file: Dashboard.jsx:44 ~ importAccount ~ mode", mode)
        options.password = mode
        console.log("🚀 ~ file: Dashboard.jsx:38 ~ importAccount ~ options", options)
        axios.post('/wallet/login/import/account', options)
          .then(function (response) {
            console.log('printing for Wallet generation response ', response);
            console.log('printing for Wallet generation response ====>', response.data.data.message.address);
            setImportedAddress([...importedAddress, { id: Date.now(), address: response.data.data.message.address }]);
            Encrypted_data.data = response.data.key.message
            console.log("🚀 ~ file: CreateWallet.jsx:35 ~ importAccount ~ Encrypted_data match this ==>", Encrypted_data)
            chrome.storage.local.set({ 'wallet_data': Encrypted_data }, () => {
              console.log('Response stored in chrome storage success');
            });
            setPublicAddress([...publicAddress, { id: Date.now(), address: response.data.address }]);
            chrome.storage.local.get(['wallet_data'], (read_data) => {
              console.log('Chrome storage data retrieved successfully==>', read_data);
            });
          })
          .catch(function (error) {
            console.log(error);
          });
      });
    } catch (error) {
      console.log(":: IMPORT_ACCOUNT_FROM_PRIVATE_KEY ::", error);
    }
  }
  return (
    
    <div className='container'>
      <h2>Decentralized Wallet Dashboard</h2>
      <button className="button button2" onClick={createAccount}>
        Create Account
      </button> <br /><br />
      <div className="row">
        <div className="column1" style={{ backgroundColor: '#aaa' }}>
          <h2>Account Address</h2>
          {/* {publicAddress} */}
          {publicAddress.map((obj) => {
            return (
              <h6 key={obj.id}>{obj.address}</h6>
            )
          })
          }
        </div>
      </div>
      <br />
      <div className="row">
        <div className="column1" style={{ backgroundColor: '#aaa' }}>
          <input type="text" placeholder="Import Using Private Key...." onChange={imp_private_key} />
          <button className="button button2" onClick={importAccountFromPrivateKey}>
            Import Account
          </button>
          <br />
          <h2>Imported Account Address</h2>
          {/* {publicAddress} */}
          {importedAddress.map((obj) => {
            return (
              <h6 key={obj.id}>{obj.address}</h6>
            )
          })
          }
        </div>
      </div>
      <button className="button button1" onClick={() => navigate('/')}>
                Dashboard
            </button>

    </div>
  )
}

export default Dashboard




//* Create Account old code
      // await axios.post('/wallet/login/account', options)
      //   .then(function (response) {
      //     console.log('printing for Wallet generation response ', response);
          // setExportedPrivateKey([...exportedPrivateKey, { id: Date.now(), privateKey: response.data.message.privateKey }]);
          // setExportedAddress([...exported_address, { id: Date.now(), address: response.data.message.address }]);
          // setMnemonics(response.data.message.mnemonics);
          // setCount(count + 1);
          // setPublicAddress([...publicAddress, { id: Date.now(), privateKey: exportedPrivateKey, address: exported_address }])
      //   })
      //   .catch(function (error) {
      //     console.log(error);
      //   });
      // await axios.post('/crypto/decrypt', obj)
      //   .then((result) => {
      //     console.log("result FORMAT ---------->", result.data.message);
      //     nemno = result.data.message
      //     setMnemonics(nemno);
      //     console.log('checking for mnemonics', mnemonics)
      //   }).catch(function (error) {
      //     console.log(error);
      //   })
      // if (mnemonics) {
      //   let options = {
      //     index: count,
      //     mnemonics: mnemonics
      //   }
      //   await axios.post('/wallet/generateAccounts', options)
      //     .then(function (response) {
      //       console.log('printing for Wallet generation ', response.data.message);
      //       setExportedPrivateKey([...exportedPrivateKey, { id: Date.now(), privateKey: response.data.message.privateKey }]);
      //       setExportedAddress([...exported_address, { id: Date.now(), address: response.data.message.address }]);
            // setMnemonics(response.data.message.mnemonics);
      //       setCount(count + 1);
            // setPublicAddress([...publicAddress, { id: Date.now(), privateKey: exportedPrivateKey, address: exported_address }])
      //     })
      //     .catch(function (error) {
      //       console.log(error);
      //     });

      //   console.log('printing test data publicAddress', publicAddress)
      // } else {
      //   console.log('mnemonics data is empty======> ')
      // }

//* Import Account old code
  // await axios.post('/wallet/login/import/account', options)
      //   .then(function (response) {
      //     console.log(response.data.message);
      //     setImportedAddress(response.data.message.address);
          // let info, options;
          // chrome.storage.local.get(['key'], function(items) {
          //     var allKeys = Object.keys(items);
          //     console.log("asd",allKeys);
          // });
          // chrome.storage.local.get('key', async function (res) {
          //   console.log('Import Value is set to ' + res.key);
          //   options = {
          //     data: res.key.data
          //   }
          //   console.log("data", res.key.data);
          //   console.log("OPTIONS", options);
          //   await axios.post('/crypto/decrypt', options)
          //     .then(async function (res) {
          //       console.log("IMPORT RESPONSE", res.data.message)
          //       info = res.data.message;
          //       info.push(
          //         {
          //           "type": "Simple Key Pair",
          //           "data": [`${privateKey}`]
          //         }
          //       )
          //       let params = {
          //         data: info
          //       }
          //       await axios.post('/crypto/encrypt', params)
          //         .then(async function (res) {
          //           console.log("ENCRYPTED FORMAT", res.data);
                    // chrome.storage.local.remove('key', async function (res) {
                    //     console.log("Response", res);
                    // })
          //           chrome.storage.local.clear(function () {
          //             var error = chrome.runtime.lastError;
          //             if (error) {
          //               console.error(error);
          //             }
          //             console.log(":: CLEAR ::", error);
          //           })
          //           chrome.storage.local.set({ 'key': { data: res.data.message } }, async function () {
          //             console.log('UPDATED DATA ' + res.data.message);
          //           });
          //         })
          //     })
          // })
          // chrome.storage.local.get('key', async function (res) {
          //     console.log("res", res);
          //     console.log("res.key", res.key);
          //     if (res.key != "") {
          // chrome.storage.local.remove('key', async function (result) {
          //     console.log("Response", result);
          // })
          //         await axios.post('/crypto/decrypt', options)
          //             .then(async function (res) {
          //                 console.log("RESPONSE", res.data.message)
          //                 console.log("RESPONSE", typeof (res.data.message))
          // info = res.data.message;
          // info.push(
          //     {
          //         "type": "Simple Key Pair",
          //         "data": [`${privateKey}`]
          //     }
          // )
          // console.log("UPDATED", info)
          // let params = {
          //     data: info
          // }
          //                 await axios.post('/crypto/encrypt', params)
          //                     .then(async function (res) {
          //                         console.log("ENCRYPTED FORMAT", res.data);
          //                         chrome.storage.local.set({ key: { data: res.data.message } }, async function () {
          //                             console.log('Value is set to ' + res.data.message);
          //                         });
          //                         console.log(":: 129479124812 ::");
          //                     })
          //             })
          //     }
          // })
      //   })
      //   .catch(function (error) {
      //     console.log(error);
      //   });
      //*html
      //  {/* <input type="text" placeholder="Import Using Private Key...." onChange={imp_private_key} />
      // <br />
      // <button className="button button2" onClick={importAccountFromPrivateKey}>
      //   Import Account
      // </button> */}
      // {/* <div>
      //   <div className="columnd" style={{ backgroundColor: '#ccc' }}>
      //     <h2>Private Key</h2>
      //     <h6>{privateKey}</h6>
      //   </div>
      //   <div className="columnd" style={{ backgroundColor: '#ccc' }}>
      //     <h2>Account Address</h2>
      //     <h6>{importedAddress}</h6>
      //   </div>
      // </div> */}
      //*
       // const [mnemonics, setMnemonics] = useState();
  // const [count, setCount] = useState(0);

  //  //* Create Account
  //  const [exportedPrivateKey, setExportedPrivateKey] = useState([]);
  //  const [exported_address, setExportedAddress] = useState([]);
