// const buttonTag = document.getElementsByClassName("trigger");

// buttonTag[0].addEventListener("click", () => {
//   chrome.runtime.sendMessage("tefahdbshdg");
// });

// var script = document.createElement("script");
// script.src = chrome.runtime.getURL("globalAPI.js");
// script.innerHTML = `
//   window.myAPIii = {
//     getData: aync() => {
//       console.log("asdasjd")
//     }
//   };
// `;

chrome.runtime.sendMessage({myAPI: true}, async(response) => {

  window.dripp = response;

  // window.postMessage({ type: 'globalAPIInjected', drippAPI: window.dripp }, '*');

  // var event = new CustomEvent("dripp");
  // window.dispatchEvent(new CustomEvent('dripps', { detail: window.dripp }));

  // console.log("🚀 ~ file: contentScript.js:12 ~ chrome.runtime.sendMessage ~ event", event)
  console.log(" :: Window :: ", window)
  // console.log(" :: window.dripp ::", window.dripp);  

})


