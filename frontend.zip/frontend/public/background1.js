// chrome.alarms.create({
//   periodInMinutes: 20 / 60,
// });

// chrome.alarms.onAlarm.addListener((alarm) => {
//   const notificationTime = 10000;

//   this.registration.showNotification("DRIPP", {
//     body: `${notificationTime} Transaction is successful`,
//     icon: "icon.png",
//   });
//   });
// });

chrome.runtime.onMessage.addListener(function (response, sender, sendResponse) {
    console.log("🚀 ~ file: background.js:15 ~ sendResponse", sendResponse)
    console.log("🚀 ~ file: background.js:15 ~ sender", sender)
    console.log("🚀 ~ file: background.js:15 ~ response", response)
  
    var url = chrome.runtime.getURL("./index.html");
  
    chrome.windows.create({
      url: url,
      type: "popup",
      focused: true,
      height: 300,
      width: 350,
    });
  
    var dripp = {
      getData : async() => {
        console.log("dripp global API is available")
      }
    };
    //contextMenu
    chrome.runtime.dripp = dripp;
    console.log("🚀 ~ file: background.js:45 ~ dripp", dripp)
  
    // var dripp = "Hai from dripp.com"
  
    chrome.tabs.sendMessage(sender.tab.id, dripp);
  
  });
  
  chrome.windows.onRemoved.addListener((windowId) => {
    console.log("🚀 ~ file: background.js:31 ~ chrome.windows.onRemoved.addListener ~ windowId", windowId)
  });
  
  chrome.windows.onRemoved.removeListener((windowId) => {
    console.log("🚀 ~ file: background.js:35 ~ chrome.windows.onRemoved.removeListener ~ windowId", windowId)
  });
  
  
  
  // chrome.tabs.query({}, function(tabs) {
  //   tabs.forEach(function(tab) {
  //     chrome.tabs.sendMessage(tab.id, dripp);
  //   });
  // });