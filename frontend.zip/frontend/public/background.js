const injectAPI = async() => {

  window.drippss = {
    getData : async() => {
      return "window.dripp available"
    }
  };

  return window.drippss;

}

const getTabId = async() => {

  let tabId;

  return new Promise((resolve, reject) => {
    chrome.tabs.query({active: true, currentWindow: true}, async(tabs) => {
      if(tabs.length > 0) {
        resolve(tabs[0].id);
      } else {
        reject(new Error("No active tab found"));
      }
    })
  })
}

chrome.runtime.onMessage.addListener(function (response, sender, sendResponse) {
  console.log("🚀 ~ file: background.js:15 ~ sendResponse", sendResponse);
  console.log("🚀 ~ file: background.js:15 ~ sender", sender);
  console.log("🚀 ~ file: background.js:15 ~ response", response);

  var url = chrome.runtime.getURL("./index.html");

  // chrome.windows.create({
  //   url: url,
  //   type: "popup",
  //   focused: true,
  //   height: 300,
  //   width: 350,
  // });

  // const contentScript = {
  //   id: 'my-content-script-1',
  //   js: ['globalAPI.js'],
  //   runAt: 'document_end',
  //   allFrames: true,
  //   "matches": ["<all_urls>"],
  // };


  getTabId().then(tabId => {
    chrome.scripting.executeScript({
      target: {tabId: tabId, allFrames:true},
      func: injectAPI
    })
    .then((result) => {
      // sendResponse(injectAPI)
      console.log("Injected a injectAPI function", result);
    })
    .catch(error => console.log(error));
  })

});

chrome.windows.onRemoved.addListener((windowId) => {
  console.log("🚀 ~ file: background.js:31 ~ chrome.windows.onRemoved.addListener ~ windowId", windowId)
});

chrome.windows.onRemoved.removeListener((windowId) => {
  console.log("🚀 ~ file: background.js:35 ~ chrome.windows.onRemoved.removeListener ~ windowId", windowId)
});

