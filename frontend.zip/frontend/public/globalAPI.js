window.dripp = {
    getData : async() => {
      return "window.dripp available"
    }
};

console.log("GLOBAL API JS FILE DETECTED", window.dripp);