const buttonTag = document.getElementsByClassName("trigger");

buttonTag[0].addEventListener("click", () => {
  chrome.runtime.sendMessage("tefahdbshdg");
});

chrome.runtime.onMessage.addListener(function (message) {
  console.log("🚀 ~ file: contentScript.js:8 ~ message", message)
  var myGlobalAPI = chrome.runtime.dripp;
  console.log("From content Script", myGlobalAPI);
  // if (message) {
  //   var myGlobalAPI = chrome.runtime.dripp;
  //   console.log("From content Script", myGlobalAPI);
  // }

});



