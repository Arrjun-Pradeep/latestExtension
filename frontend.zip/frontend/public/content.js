const buttonTag = document.getElementsByClassName("trigger");

buttonTag[0].addEventListener("click", () => {
  chrome.runtime.sendMessage("tefahdbshdg");
});

var window.sddripp = {

  getData: async() => {
    console.log("GOT ITTTTTTTTTTTTTTTTTTTTTT")
  }
}

console.log("Inside CONTENT_SCRIPTS", window);

window.dispatchEvent(new CustomEvent("dripp"))

// var nonce = btoa(Math.random())
// var script = document.createElement('script');
// script.textContent = 'window.dispatchEvent(new CustomEvent("dripp"));';
// script.nonce = nonce;
// (document.head || document.documentElement).appendChild(script);
// script.remove();

// var script = document.createElement('script');
// script.textContent = 'window.dispatchEvent(new CustomEvent("dripp"));';
// (document.head || document.documentElement).appendChild(script);
// script.remove();